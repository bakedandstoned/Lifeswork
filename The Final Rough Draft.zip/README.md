# Elite Blog Monetization Platform

## 🚀 Setup

1. Install dependencies:
```bash
npm install
```

2. Run the development server:
```bash
npm run dev
```

3. Visit [http://localhost:3000](http://localhost:3000)

## 🔐 Environment

Create `.env.local` and add:
```
OPENAI_API_KEY=your-api-key
MAILCHIMP_URL=https://your-mailchimp-endpoint
STRIPE_LINK1=https://buy.stripe.com/link1
STRIPE_LINK2=https://buy.stripe.com/link2
```

## 🔥 Features
- Blog post editor with AI generation
- Real-time post list, likes, filtering
- Poll, lead magnet, and Stripe product links
- Tailwind + Framer Motion + Dark Mode
- Fully responsive and SEO optimized
